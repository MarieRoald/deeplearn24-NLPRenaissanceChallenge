# DeepLearn 2024 Hackathon - RenAIssance: OCR for Seventeenth Century Spanish Texts 

## Info 
See [our github repo](https://github.com/MarieRoald/deeplearn24-NLPRenaissanceChallenge/) for all code and experiments.  
Our best model is on huggingface, so it is easy to download and use (it will be downloaded first time the notebook is run)  
All of our deliverables are available online, so we provide a list of external links as well as internal to this directory, in case that is more convenient.

### Team members 
- Marie Roald (marie.roald@nb.no)
- Tita Enstad (tita.enstad@nb.no)

### Installation and environment
We have tested that this works with python >=3.10  
All python packages needed to run `local_notebook.ipynb` are listed in `requirements.txt`  
Create a virtual environment and install the requirements like this:
```
python3 -m venv venv_hackathon
. venv_hackathon/bin/activate
pip install -r requirements
```

You should be able to run `colab_notebook.ipynb` in google colab without any issues (it is already online [here](https://colab.research.google.com/drive/1965CaHaNlMLosCKp-cCW7axqoZUn7RaL?usp=sharing) )


## Deliverables (internal links)
- Our best OCR-model was too big to upload to the form but can be found is [here](https://huggingface.co/MarieRoald/DeepLearn24OCRChallenge) 
- [Predictions (one file)](all_text.txt) / [Predictions (one file per page)](predictions_per_page/) 
- [Notebook (run in google colab)](colab_notebook.ipynb) / [Notebook for running locally (in github repo)](local_notebook.ipynb)
- [Report](deeplearn_report.pdf)

## Deliverables (external links) 
- [Our best OCR-model](https://huggingface.co/MarieRoald/DeepLearn24OCRChallenge) 
- [Predictions (one file)](https://github.com/MarieRoald/deeplearn24-NLPRenaissanceChallenge/blob/main/data/best_model_test_predictions/all_text.txt) / [Predictions (one file per page)](https://github.com/MarieRoald/deeplearn24-NLPRenaissanceChallenge/tree/main/data/best_model_test_predictions)
- [Notebook (google colab)](https://colab.research.google.com/drive/1965CaHaNlMLosCKp-cCW7axqoZUn7RaL?usp=sharing) / [Notebook for running locally (in github repo)](https://github.com/MarieRoald/deeplearn24-NLPRenaissanceChallenge/blob/main/notebooks/DeepLearn2024_ocr_hackathon.ipynb)
- [Report](https://github.com/MarieRoald/deeplearn24-NLPRenaissanceChallenge/blob/main/deeplearn_report.pdf)

